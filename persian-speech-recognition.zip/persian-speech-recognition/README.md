# Persian Speech recognition

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aghaie/pen/EzgdEo](https://codepen.io/Aghaie/pen/EzgdEo).

Using Angular to to update the view. Chrome only and you must allow access to the mic.